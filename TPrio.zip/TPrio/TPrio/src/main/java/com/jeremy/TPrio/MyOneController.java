package com.jeremy.TPrio;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import jakarta.servlet.http.HttpServletRequest;

@RestController
public class MyOneController {
	private final AtomicLong counter = new AtomicLong();

	@GetMapping("/bonjour")
	public Hello hello(@RequestParam(value = "name", defaultValue = "Inconnu") String name) {
		return new Hello(counter.incrementAndGet(), String.format("Hello, %s!", name));
	}

	@RequestMapping(value = "/hello/**", method = RequestMethod.GET)
	@ResponseBody
	public String hello(HttpServletRequest request) {
		String requestURL = request.getRequestURL().toString();
		String arg[] = requestURL.split("/");
		String prenom = arg[4];
		String nom = arg[5];
		return String.format("bonjour %s %s", prenom, nom.toUpperCase());
	}

//@CrossOrigin(origins = "http://localhost:8080")
	@CrossOrigin
	@GetMapping("/meteo")
	public String ajax(HttpServletRequest request) {
		return "Meteo de jerem";
	}

	// @CrossOrigin(origins = "http://localhost:8080")
	@CrossOrigin
	@GetMapping("/livre")
	public String ajaxLivre(HttpServletRequest request) {
		return "nouveau livre";
	}

	// TP1: lancer la page bibliotheque avec comme argument titre=TITRE et auteur=AUTEUR 
	// http://localhost:8080/bibliotheque?titre=TITRE&auteur=AUTEUR
	@GetMapping("/bibliotheque")
	public Livre livre(@RequestParam(value = "titre", defaultValue = "Pas de titre") String titre,
			@RequestParam(value = "auteur", defaultValue = "Pas d auteur") String auteur) {
		return new Livre(String.format("   %s   ", titre), String.format("   %s   ", auteur));
	}
	// TP2: lancer la page afficherLivre avec comme argument titre=TITRE et auteur=AUTEUR 
	@RequestMapping(value = "/afficherLivre/**", method = RequestMethod.GET)
	@ResponseBody
	public String afficherLivre(HttpServletRequest request) {
		String requestURL = request.getRequestURL().toString();
		String arg[] = requestURL.split("/");
		String titre = arg[4];
		String auteur = arg[5];
		return String.format("%s, %s", titre, auteur);
	}
	// TP3: lancer la page calculer qui renvoie la somme de deux arguments
	@RequestMapping(value = "/calculer/**", method = RequestMethod.GET)
	@ResponseBody
	public String calculer(HttpServletRequest request) {
		String requestURL = request.getRequestURL().toString();
		String arg[] = requestURL.split("/");
		int arg1 = Integer.parseInt(arg[4]);
		int arg2 = Integer.parseInt(arg[5]);
		return String.format("%d + %d = %d", arg1, arg2, arg1+arg2);
	}
}
