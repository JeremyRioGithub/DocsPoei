package com.jeremy.TPrio;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class controllerTest {
	
	@GetMapping("/")
	public String bienvenue(HttpServletRequest request) {
		return "Bienvenue."
				+ "<table class=\"tftable\" border=\"1\">"
				+ "<tr><th>TOTO</th><th>MARTINE</th><th>CHAUSSETTE</th><th>LIVRE</th></tr>"
				+ "<tr><td><a href=\"toto\">Aller voir Toto.</a></td>"
				+ "<td><a href=\"martine\">Aller voir Martine.</a></td>\"\r\n"
				+ "<td><a href=\"chaussette\">Aller voir Chaussette.</a></td>"
				+ "<td><a href=\"testAPIGET.html\">Aller voir Livre.</a></td></tr>"
				+ "</table>";
	}
	
	@GetMapping("/toto")
	public String toto(HttpServletRequest request) {
		return "Bonjour Toto";
	}
	
	@GetMapping("/martine")
	public String martine(HttpServletRequest request) {
		return "Bonjour Martine";
	}
	
	@GetMapping("/chaussette")
	public Chaussette chaussette(HttpServletRequest request) {
		Chaussette chaus = new Chaussette("noel", "laine", 41);
		return chaus;
	}
}
