package com.jeremy.TPrio;

import java.util.ArrayList;
import java.util.Map;

//import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@CrossOrigin
@RestController
public class PostController {
	private static ArrayList<Livre> listeLivres = new ArrayList<Livre>();
	private Livre book;
	private Connexion userPass;
	private int charcute;
	private String strincute;
	private int charcutePass;
	private String strincutePass;
	@SuppressWarnings("rawtypes")
	@PostMapping("/createLivre") // methode pour du JSON pur
	public ResponseEntity getLivre(@RequestBody Map<String, String> request) {
		System.out.println(request.get("titre") + " de " + request.get("auteur"));
		return ResponseEntity.ok(request.get("titre") + " de " + request.get("auteur"));
	}

	@PostMapping("/addLivre")
	public String addLivre(@RequestBody Livre livre) {
		this.book=livre;
		listeLivres.add(livre);
		System.out.println(livre);
		return livre.toString();
	}

	@GetMapping("/getLivre")
	public Livre ajax(HttpServletRequest request) {
		return this.book;
	}
	
	@GetMapping("/getListeLivres")
	public ArrayList<Livre> getListeLivres(HttpServletRequest request) {
		return listeLivres;
	}

	@PostMapping("/addConnexion")
	public void addConnexion(@RequestBody Connexion connexion) {
		this.userPass = connexion;
		System.out.println(connexion);
		strincute = Integer.toString(this.userPass.getUser().charAt(0)%11) + 
				Integer.toString(this.userPass.getUser().charAt(1)%13) +
				Integer.toString(this.userPass.getUser().charAt(2)%17) +
				Integer.toString(this.userPass.getUser().charAt(3)%19) +
				Integer.toString(this.userPass.getUser().charAt(4)%23) +
				Integer.toString(this.userPass.getUser().charAt(5)%29);
		charcute = Integer.parseInt(strincute);
		strincutePass = Integer.toString(this.userPass.getPassword().charAt(0)%11) + 
				Integer.toString(this.userPass.getPassword().charAt(1)%13) +
				Integer.toString(this.userPass.getPassword().charAt(2)%17) +
				Integer.toString(this.userPass.getPassword().charAt(3)%19);
		charcutePass = Integer.parseInt(strincutePass);
		System.out.println(charcute+", "+charcutePass);
	}

	@GetMapping("/getConnexion")
	public String getConnexion(HttpServletRequest request) {
		//charcute = 106%11+101%13+114%17+101%19+109%23+121%29;
		//charcute = 7+10+12+6+17+5;
		strincute = Integer.toString(this.userPass.getUser().charAt(0)%11) + 
				Integer.toString(this.userPass.getUser().charAt(1)%13) +
				Integer.toString(this.userPass.getUser().charAt(2)%17) +
				Integer.toString(this.userPass.getUser().charAt(3)%19) +
				Integer.toString(this.userPass.getUser().charAt(4)%23) +
				Integer.toString(this.userPass.getUser().charAt(5)%29);
		charcute = Integer.parseInt(strincute);
		strincutePass = Integer.toString(this.userPass.getPassword().charAt(0)%11) + 
				Integer.toString(this.userPass.getPassword().charAt(1)%13) +
				Integer.toString(this.userPass.getPassword().charAt(2)%17) +
				Integer.toString(this.userPass.getPassword().charAt(3)%19);
		charcutePass = Integer.parseInt(strincutePass);
		//System.out.println(charcute+", "+charcutePass);
		if (this.userPass.getUser().equals("JEREMY") && this.userPass.getPassword().equals("PASS"))
			return "OK but not secure";
		else if(charcute==710126175 && charcutePass==26131)
			return "OK secure";
		else
			return "STOP";
	}
}
