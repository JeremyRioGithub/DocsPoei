package com.jeremy.TPrio;

public class Chaussette {
	private String couleur;
	private String matiere;
	private int taille;
	public Chaussette(String couleur, String matiere, int taille) {
		this.couleur = couleur;
		this.matiere = matiere;
		this.taille = taille;
	}
	public String getCouleur() {
		return couleur;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public String getMatiere() {
		return matiere;
	}
	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}
	public int getTaille() {
		return taille;
	}
	public void setTaille(int taille) {
		this.taille = taille;
	}
	@Override
	public String toString() {
		return "Chaussette [couleur=" + couleur + ", matiere=" + matiere + ", taille=" + taille + "]";
	}
}
