package com.jeremy.TPrio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TPrioApplication {

	public static void main(String[] args) {
		SpringApplication.run(TPrioApplication.class, args);
	}

}
