package com.jeremy.TPrio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TPrioApplicationTests {

	@Test
	void contextLoads() {
	}

}
