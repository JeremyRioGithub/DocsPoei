#!/bin/sh

folder=$1
startFolder=$(pwd)
cd $1

for compteur in $(ls -1); do
    wordToBeChanged=XXXXXXXXXXX
    changeWordBy=xxxxxxxxxxxxx
	cat $compteur | sed -e "s/"$wordToBeChanged"/"$changeWordBy"/g" > $compteur".tmp" ; mv $compteur".tmp" $compteur ;

	/c/Users/ib/Desktop/TRAVAIL/umlet-standalone-15.0.0/Umlet/umlet.sh -action=convert -format=jpg -filename="$compteur"
done

cd $startFolder
