#!/bin/sh

folder=$1
startFolder=$(pwd)
cd $1

wordToBeChanged=Training_theme
changeWordBy=TrainingTheme
for compteur in $(ls -1); do
	cat $compteur | sed -e "s/"$wordToBeChanged"/"$changeWordBy"/g" > $compteur".tmp" ; mv $compteur".tmp" $compteur ;
done

cd $startFolder
